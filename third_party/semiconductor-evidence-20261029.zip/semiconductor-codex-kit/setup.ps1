param([ValidateSet('workspace','plugin')][string]$Mode='workspace')
$ErrorActionPreference='Stop'
$packageRoot=$PSScriptRoot
$pythonExecutable=$null
foreach($candidate in @('python','py')) {
    $found=Get-Command $candidate -ErrorAction SilentlyContinue
    if($found) {
        $probeArgs=@('-c','import sys; print(sys.executable); sys.exit(0 if sys.version_info >= (3,12) else 2)')
        if($candidate -eq 'py') { $probeArgs=@('-3')+$probeArgs }
        $probe=& $found.Source @probeArgs 2>$null
        if($LASTEXITCODE -eq 0 -and $probe) { $pythonExecutable=($probe | Select-Object -Last 1);break }
    }
}
if(-not $pythonExecutable) { throw 'Python 3.12 or later is required. Install Python, then retry.' }
& $pythonExecutable -X utf8 (Join-Path $packageRoot 'scripts\configure.py') --mode $Mode
if($LASTEXITCODE -ne 0) { throw 'Setup did not complete. Review the message above.' }
