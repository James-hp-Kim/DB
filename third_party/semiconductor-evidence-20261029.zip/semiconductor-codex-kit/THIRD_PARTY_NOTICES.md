# 제3자 자료 및 배포 범위

수집된 원문은 각 원저작자의 자료이며 이 프로젝트의 코드와 동일 라이선스로 재허가하지 않는다. `plugins/chip-evidence/evidence/references/sources/`의 저장소별 LICENSE/COPYING과 provenance를 함께 보존한다. source-files.json은 원본 URL, commit, blob SHA-1 및 SHA-256을 기록한다. 수정하지 않은 선택 파일이며 전체 저장소 실행 패키지가 아니다.

ngspice 47 manual은 원본 PDF의 CC-BY-SA-4.0 및 페이지 2 예외를 따른다. TI SLOA020A는 원본 재현 고지와 저작권 문구를 보존한 PDF다. 두 PDF의 문헌 확인이 모든 문장 정확성 검증을 뜻하지 않는다. 이 배포판 DB는 PDF 본문 전체를 추출하지 않고 해당 문헌의 자체 요약·위치·원본 링크를 제공한다.

Arcadia-1 두 저장소는 README의 MIT 표기와 별개 LICENSE 본문을 확인하지 못해 원문을 넣지 않았다. 링크와 자체 검토만 포함한다. 링크만 포함한 문헌은 오프라인에서 전체 본문을 읽을 수 없다.

PicoRV32는 ISC COPYING을 원본 및 변형본 옆에 포함한다. M01~M06 RTL은 진단 시험용으로 고의 변경한 사본이며 업스트림 결함이라고 주장하지 않는다. upstream-testbench_ez.v의 public-domain 고지도 보존했다.

EDA 실행 바이너리는 배포하지 않는다. 필요한 경우 공식 배포본을 직접 내려받는 선택 스크립트를 제공한다. 각 도구의 조건은 해당 배포본을 따른다. 새 작성 코드의 공개 라이선스 선택은 저장소 소유자가 결정하도록 별도 포괄 LICENSE를 임의로 붙이지 않았다. GitHub 공개 업로드와 공개 라이선스 부여는 별개의 선택이다.
