# 데이터베이스 구조와 갱신

SQLite `knowledge.sqlite`는 재생성 가능한 검색 인덱스입니다. `records.jsonl`이 사람이 검토할 수 있는 검색 레코드 원장이고, evidence 아래 원문·로그가 실제 증거입니다. 모델 가중치·대화 기억·API 키를 저장하지 않습니다.

## 기록 종류

|kind|내용|판정 의미|
|---|---|---|
|source|48개 출처의 제목·지원 범위·한계·링크|존재/관련 본문 확인; 전체 정확성 인증 아님|
|claim|40개 주장 검토와 교정|확인/조건부/근거 부족/미확인 구분|
|source_text|선택한 GitHub 원문의 행 단위 조각|원문 무결성 확인; 기술적으로 오류일 수 있음|
|experiment|실제 시행한 공개 CPU 시험·설정별 비교|주어진 입력과 조건에서 관측|
|guide|설치, 검증 범위, 입력별 검토 지침|패키지 사용 절차|

모든 기록은 고유 ID, 제목, 상태, 원본 URL, 패키지 내 상대 경로, 가능한 경우 행 번호·SHA-256, 관련 교정 ID, 본문을 갖습니다. DB에는 API 키나 회사 내부 자료가 없습니다. 선택 원문에는 저작자의 공개 이름/링크가 원래대로 있을 수 있습니다.

FTS5 키워드 검색과 한글 부분문자열 보완, 작은 한영 기술어 사전을 사용합니다. 의미 임베딩 모델은 없습니다. 질문이 길거나 결과가 부적절하면 Codex가 기술어를 좁혀 재검색하도록 스킬에 안내했습니다. 원문 관련 교정 레코드를 함께 조회해야 합니다. PDF 본문은 인덱싱하지 않았으며, PDF 관련 질문은 문헌 기록의 위치와 원본 PDF를 열어 확인합니다.

`search_evidence(query, limit, kind)` → `get_evidence(record_id, offset, max_chars)` 순서로 읽습니다. `knowledge_status()`는 기록 수·스냅샷·DB 검사를, `benchmark_results()`는 관측 결과를 반환합니다. MCP는 읽기 전용이고 임의 SQL·파일 경로·쉘 실행 도구를 노출하지 않습니다.

## 새 자료를 추가할 때

1. 원본 URL, 고정 commit/version, 취득일, 사용 조건과 원본 해시를 먼저 기록합니다. 검토 전 원문을 교정된 사실로 등록하지 않습니다.
2. `records.jsonl`에 동일 구조의 새 ID를 추가합니다. 기존 ID의 판정이 바뀌면 이유·새 근거를 남겨 변경 이력을 Git에서 볼 수 있게 합니다. 원문 사본은 덮어쓰지 않고 새 버전을 추가합니다.
3. 새 원문 조각에는 관련 `claim` ID를 연결합니다. 직접 확인하지 못한 내용은 `미검증`으로 기록합니다.
4. 아래 명령으로 DB를 재생성한 뒤 시험·새 해시 manifest를 생성합니다.

```powershell
python -X utf8 .\plugins\chip-evidence\runtime\rebuild_database.py
python -X utf8 .\scripts\test_package.py
python -X utf8 .\scripts\make_manifest.py
python -X utf8 .\scripts\doctor.py
```

manifest 갱신은 변경된 자료를 검토하고 시험한 후 수행합니다. 무결성 검사는 내용이 배포 시점과 같은지 확인할 뿐, 기술적 진실을 증명하지 않습니다.

## 보존과 공개 범위

외부 원문은 수정 없이 evidence에 두고, 잘못된 부분은 별도 claim에서 교정합니다. catalog와 provenance의 “실행 안 함”은 최초 자료 수집 시점의 상태입니다. 이후 PicoRV32/Icarus/Yosys 실험의 최신 상태는 E00과 `evidence/validation/summary.json`을 우선 확인합니다. 다른 수집 도구까지 실행 검증한 것으로 확대하지 않습니다.

GitHub에는 패키지 루트의 배포 파일만 올립니다. `.local`, `.tools`, `work`, 사용자 설정, API 키, 실제 회사 칩 파일은 포함하지 않습니다. `.gitignore`와 배포 manifest가 범위를 설명합니다. 자동 동기화·원격 업로드·자격증명 저장 기능은 없습니다.
