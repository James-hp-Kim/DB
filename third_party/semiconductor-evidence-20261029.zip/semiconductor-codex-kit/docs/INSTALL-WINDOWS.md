# Windows Codex 설치 안내

대상은 Windows x64와 Codex입니다. 이 패키지를 다른 컴퓨터에 복사해도 이전 대화나 개인 메모리가 필요하지 않습니다. GitHub에 파일이 있다는 것만으로 Codex에 자동 설치되지는 않습니다.

## 필수 설치

1. **Codex**: 공식 배포 경로에서 설치하고 자신의 계정으로 로그인합니다. 이미 있다면 그대로 사용합니다.
2. **Python 3.12 이상**: [python.org Windows](https://www.python.org/downloads/windows/)의 x64 설치본. Python을 명령으로 찾을 수 있도록 설치 옵션을 확인합니다. `python --version` 또는 `py -3 --version`으로 확인합니다. 이 배포본은 Python 3.14에서 실행 시험했습니다. 3.12 이상 호환을 목표로 했지만 모든 버전에서 실행한 것은 아닙니다.
3. **저장소 폴더**: GitHub Download ZIP을 풀거나 Git으로 내려받습니다. 폴더는 실행 중 이동하지 않습니다. 이동했다면 setup을 다시 실행하여 절대 경로 설정을 갱신합니다.

Microsoft Store의 Python 실행 별칭만 있고 실제 Python이 없으면 설치가 완료된 것이 아닙니다. `setup.ps1`이 버전 확인에 실패하면 Python 설치/실행 경로를 먼저 해결합니다.

## 권장: 한 프로젝트에서 바로 사용

Codex에서 이 저장소 폴더를 프로젝트로 열고 설치를 요청하거나 PowerShell에서 다음을 실행합니다.

```powershell
.\setup.ps1
```

실행 정책 때문에 차단되면 정책을 전역 변경하지 않고 Python으로 같은 설정 도구를 실행할 수 있습니다.

```powershell
python -X utf8 .\scripts\configure.py --mode workspace
```

설치기는 DB 상태를 검사한 다음 `.agents/skills/`에 교정 스킬을 복사하고 `.codex/config.toml`에 `chip_evidence` MCP를 설정합니다. 현재 Python과 서버의 절대 경로를 사용합니다. 기존 설정 파일은 덮어쓰지 않고 `.local/mcp-config.toml`에 병합할 내용을 만듭니다. 같은 내용이면 변경하지 않습니다. 동명 스킬의 내용이 다르면 충돌로 중단합니다. 생성 파일 목록은 `.local/setup-result.json`에 있습니다.

Codex에서 이 프로젝트를 신뢰한 다음 다시 열고 `knowledge_status`, `search_evidence`가 제공되는지 확인합니다. “MCP의 knowledge_status를 실행하고 C06을 찾아줘”라고 요청합니다. 설정 파일 생성만으로 실제 연결 성공이라고 판단하지 않습니다. 연결이 안 되면 아래 직접 검색으로 DB부터 확인합니다.

## 모든 프로젝트에서 사용

프로젝트 방식으로 먼저 확인한 다음, Codex 설정의 MCP 서버 추가에서 STDIO를 선택합니다. command와 args는 `.local/mcp-config.toml`의 값을 그대로 사용합니다. 계정/앱 버전에서 제공하는 설정 UI가 다를 수 있으므로 서버 유형·명령·인수 기준으로 설정합니다.

Codex CLI가 별도로 설치되어 있다면 다음 형식도 가능합니다. `<...>`는 실제 `.local/mcp-config.toml`의 절대 경로로 바꿉니다.

```powershell
codex mcp add chip_evidence -- "<python.exe 절대경로>" -X utf8 "<runtime/server.py 절대경로>"
codex mcp list
```

전역 스킬은 `$HOME/.agents/skills` 또는 현재 Codex가 지원하는 사용자 스킬 위치에 설치할 수 있습니다. 이 패키지는 사용자 전역 폴더를 자동 변경하지 않습니다. 다른 프로젝트에서 플러그인 방식으로 쓰면 별도 스킬 복사 없이 설치된 스킬을 선택할 수 있습니다.

## 선택: Codex 플러그인 형태

플러그인은 스킬·DB·MCP 서버 코드를 함께 담는 배포 단위입니다. 이 버전은 **스킬 플러그인 + 명시적인 MCP 설정** 구조입니다. manifest만 설치했다고 MCP가 자동 등록되지는 않습니다. 앱별 플러그인 실행 경로 변수에 의존하지 않도록 설치 단계에서 서버 절대 경로를 만듭니다.

1. workspace 스킬 방식을 아직 설치하지 않았다면 `setup.ps1 -Mode plugin`으로 MCP 설정만 준비합니다.
2. Codex에서 저장소의 `.agents/plugins/marketplace.json`을 로컬 마켓플레이스로 추가하고 `chip-evidence`를 설치합니다. Codex CLI가 있다면 저장소 루트에서 다음을 사용할 수 있습니다.

```powershell
codex plugin marketplace add .
codex plugin add chip-evidence@semiconductor-evidence-local
```

3. Codex를 다시 열고 스킬과 MCP 응답을 따로 확인합니다. 기본 workspace 방식과 플러그인 방식을 동시에 쓰면 같은 스킬이 중복 표시될 수 있습니다.

GitHub 업로드 후에는 `codex plugin marketplace add OWNER/REPOSITORY --ref COMMIT`처럼 고정 버전으로 등록할 수 있습니다. OWNER/REPOSITORY는 실제 업로드 후 결정하며 이 배포본에는 가짜 저장소 URL을 넣지 않았습니다. 플러그인 UI에서 실제 설치·선택하는 과정은 현재 사용자의 환경을 바꾸지 않기 위해 실행하지 않았습니다. manifest와 파일 경로 검사는 별도 시험했습니다.

## 직접 검색과 점검

```powershell
python -X utf8 .\scripts\doctor.py
python -X utf8 .\plugins\chip-evidence\runtime\knowledge.py search "홀드 슬랙"
python -X utf8 .\plugins\chip-evidence\runtime\knowledge.py get C06
python -X utf8 .\plugins\chip-evidence\runtime\knowledge.py benchmark
```

검색에 Node.js, Docker, WSL, 별도 OpenAI API 키, 유료 DB는 필요하지 않습니다. 외부 자료 최신성 확인이나 Codex 모델 사용은 인터넷 연결이 필요합니다. 로컬 DB는 2026-10-29 스냅샷이며 자동 갱신하지 않습니다.

## 선택: 실제 RTL 시험 재현

실험에만 OSS CAD Suite Windows 도구가 필요합니다. 공식 배포 파일은 약 575MiB이며 압축 해제 공간도 별도로 필요합니다. 설치기는 전역 PATH를 변경하지 않습니다.

```powershell
python -X utf8 .\scripts\install_eda.py --download
python -X utf8 .\scripts\run_benchmark.py --eda-root .\.tools\oss-cad-suite --output .\work\rerun-001
python -X utf8 .\scripts\finish_benchmark.py --eda-root .\.tools\oss-cad-suite --output .\work\rerun-001
```

다운로드 없이 이미 설치된 도구 폴더를 `--eda-root`에 줄 수도 있습니다. 해시가 다른 도구 버전은 과거 결과와 동일하다고 가정하지 않습니다. 재실행 결과는 새 폴더에 쓰며 보관된 결과를 덮어쓰지 않습니다.

아날로그 분석에는 별도 SPICE·정확한 소자 모델, STA에는 Liberty/SDC/SPEF 등, 물리 설계에는 PDK/LEF/tech data와 적합한 flow가 필요합니다. DRAM/HBM/SSD 시뮬레이터는 각 도구의 지원 OS·의존성에 따라 별도 환경을 구성해야 합니다. 이번 패키지에서 Windows 실행 검증한 EDA는 Icarus/Yosys입니다. 다른 도구가 Windows에서 모두 바로 실행된다고 보장하지 않습니다.

## 제거·이동

`.local/setup-result.json`의 생성 목록을 보고 이 패키지가 만든 스킬과 `chip_evidence` 설정만 제거합니다. 기존 config.toml 전체를 지우지 않습니다. 플러그인 방식이면 Codex 플러그인 관리자에서 해제합니다. 자동 제거 스크립트는 제공하지 않습니다. 새 경로로 이동했으면 MCP를 새 경로로 갱신합니다.

공식 근거: [MCP 설정](https://learn.chatgpt.com/docs/extend/mcp?surface=cli), [스킬](https://learn.chatgpt.com/docs/build-skills), [플러그인 패키징](https://developers.openai.com/plugins/build/plugins). 연결 지원과 UI는 버전에 따라 변경될 수 있습니다.
