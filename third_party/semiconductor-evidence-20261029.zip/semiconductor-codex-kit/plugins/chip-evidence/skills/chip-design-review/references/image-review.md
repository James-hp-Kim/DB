# 이미지·회로도·레이아웃 분석

## 읽는 순서

자료가 기능 블록도, transistor 회로도, RTL 캡처, floorplan, routed layout, congestion/IR heatmap, timing/power/DRC report 중 무엇인지 판별한다. 제목·범례·단위·분석 단계가 없는 그림은 그 한계부터 기록한다.

텍스트와 수치를 직접 판독한다. 확대·추출 도구가 있으면 사용하되, OCR 오독 가능성이 있는 부호·소수점·단위를 원본과 대조한다. 읽히지 않는 값을 지어내지 않는다. 이미지 영역을 설명해 근거를 다시 찾을 수 있게 한다.

## 증거별 판단 범위

| 자료 | 확인 가능한 내용 | 추가 자료 없이 확정할 수 없는 내용 |
|---|---|---|
| RTL 캡처 | 보이는 구문의 명백한 구조·폭·조건 문제 | 다른 파일의 정의, 전체 설계의 기능, 실제 합성 결과 |
| 블록도 | 보이는 연결·경계·clock/reset 표시와 명세 간 불일치 | 생략된 내부 회로, pipeline latency, 전체 CDC 안전성 |
| transistor 회로도 | 보이는 접속·bias 경로·소자값·명시된 동작점 | 실제 gm/gds, 안정성·잡음·offset·PVT 결과 |
| floorplan/layout | 보이는 macro 위치·배선 밀집·범례가 있는 지도상의 hotspot | raster만으로 연결·short/open·spacing rule 위반, 실제 RC·DRC/LVS |
| timing report | 표시된 path·corner·mode·slack | 다른 path·corner·mode의 통과, coverage, 예외 정당성 |
| power report | 표시된 전력 종류·단위·활동 조건·합계 | 다른 workload와의 공정한 비교, 실제 silicon 측정 여부 |
| DRC/LVS summary | 표시된 실행·대상·deck에서 보고된 결과 | 누락된 block·deck·layout revision의 검증 결과 |

지도 색이 붉다는 이유만으로 실패라고 하지 않는다. 수치 범례와 과제 기준을 연결한다. 색이 비교적 진하거나 배선이 길어 보이는 관찰은 위치·확인 작업을 갖춘 가설로 남긴다.

## 조건부 개선 제안

- 혼잡 가설: hotspot과 macro pin/access 위치가 겹치는지 확인하고, 배치·halo·cell spreading·배선층 조정 후보를 비교한다. 실제 overflow와 post-route timing을 재확인해야 한다.
- 경로 지연 가설: cell delay와 net delay 분해를 요청하거나 확인한다. logic depth와 wire RC 중 무엇이 지배하는지 모르면 pipeline과 배치 개선 중 하나를 확정하지 않는다.
- 전력 가설: clock/data switching과 leakage를 구분한다. VCD/SAIF 반영 여부만으로 workload 대표성을 확정하지 않는다.
- 아날로그 가설: bias/headroom/feedback 구조를 본 뒤 동작점, AC/STB, transient, noise 중 확인이 필요한 항목을 고른다. 시뮬레이션 없이 수치적인 안정 여유나 개선율을 만들어내지 않는다.

## 그림만 주어졌는데 실제 수정을 요구하는 경우

이미지만으로 원래 설계를 정확히 복원했다고 주장하지 않는다. 가능한 것은 특정 block/net/device의 변경 명세, 필요한 원본 목록, 검증 계획이다. 사용자가 재구성 프로토타입을 원하면 새로 만든 모델이라는 점과 원본과의 차이를 명시한다.

편집 가능한 RTL/netlist/DEF/OA 등과 도구가 주어진 뒤 실제 변경을 실행한다. 회로 이미지를 수정하는 것은 전기적으로 검증된 설계 변경이 아니다.
