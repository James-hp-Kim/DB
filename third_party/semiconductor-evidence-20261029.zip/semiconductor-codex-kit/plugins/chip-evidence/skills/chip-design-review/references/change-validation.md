# 실제 수정·재검증

## 수정 전

보고서만 요청했으면 수정하지 않는다. 수정이 요청됐으면 현 프로젝트의 변경 규칙에 맞게 원본과 구분되는 후보·버전을 만든다. 기존 변경과 입력을 보존하고 기준 결과의 설계/constraint/workload 식별자를 남긴다.

기준 실행이 입력 누락·frontend 오류·license 오류로 중단됐다면 이를 칩 결함으로 해석하지 않는다. 해소할 수 있는 환경 문제를 정리하고, 실행 가능한 분석은 계속하되 실제 설계의 실패라고 주장하지 않는다.

## 변경과 검증 연결

| 변경 | 직접 확인 | 대표적인 회귀 위험 |
|---|---|---|
| combinational RTL 재구성 | reference 비교·simulation/formal·합성 | 폭/부호, priority, X/illegal input 처리 |
| pipeline/retiming | cycle-aware 비교·허용 latency와 throughput 검증 | handshake 정렬, feedback latency, reset, LEC 설정 |
| resource sharing | peak load와 arbitration·기능 회귀 | throughput·동시 접근·backpressure |
| clock gating | enable·ICG·DFT와 clock-aware 검증 | glitch, 잃어버린 update, test mode |
| cell/buffer/배치 ECO | post-ECO setup/hold·필요 시 LEC·DRC/LVS | 반대쪽 timing, congestion, power·IR |
| 아날로그 소자·보상 변경 | 적합한 DC/AC/STB/tran/noise/PVT | headroom·noise·settling·load 안정성 |

모든 검증을 기계적으로 수행하지 말고 변경에 영향을 받는 검증과 과제의 필수 gate를 선택한다. 실제 라이브 설계 환경의 save/DRC/검증 권한·범위는 사용자 지시를 따른다.

한 번에 원인을 추적할 수 있는 변경을 한다. baseline에서 드러난 문제를 동일한 자극·검사로 다시 확인하고 정상 경로와 변경 주변의 회귀도 확인한다. test나 constraint를 약하게 만들어 통과시키지 않는다. 정당한 요구사항 변경이면 별도 시나리오로 비교하고 이전 계약의 통과로 표현하지 않는다.

수정된 RTL이 일반적으로 같은 기능이어도 cycle latency가 달라졌다면 단순 combinational LEC만으로 완료하지 않는다. retiming-aware equivalence 또는 latency 정렬 reference와 명세 검토 등 적합한 방법을 사용하고 그 한계를 남긴다.

## 결과 상태

- **수정·검증 완료**: 이름 붙인 검사가 해당 입력·조건에서 실제 통과했다.
- **수정 완료·검증 일부**: 무엇이 실행됐고 무엇이 누락됐는지 구분한다.
- **수정안만 작성**: 도구 또는 입력이 없어 patch/변경 명세만 만들었다.
- **채택 보류**: 효과가 불확실하거나 필수 기능/제약을 위반한다.

검증된 범위만 완료라고 표현한다. 파일 존재나 exit code 0만으로 기능/PPA 통과를 선언하지 않는다. report와 실제 artifact revision이 맞는지 확인한다.

## 최종 비교

baseline / candidate / 조건 / 기능·latency·throughput / timing / power / area / 필수 gate / 미검증 항목을 표로 낸다. 서로 다른 workload나 corner의 숫자는 같은 열의 직접 비교값으로 묶지 않는다. 채택안과 rollback 가능한 기준 버전, 남은 확인을 전달한다.
