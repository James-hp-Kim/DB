# RTL·넷리스트·EDA 보고서 분석

## 기준선과 비교 조건

top module/cell, filelist, include/parameter 설정, clock/reset, SDC/UPF, 목표와 테스트 조건을 파악한다. gate-level이면 library/PDK/PVT, netlist revision, extraction/SPEF corner가 맞는지 확인한다. 일부만 제공되면 그 범위에서 분석한다.

보고서의 cell area와 die/core area, dynamic·leakage·total power, target frequency와 achieved frequency를 혼용하지 않는다. baseline 대비 변화율은 (후보−기준)/기준을 사용하며 기준값과 절대 차이도 제시한다. 0 또는 누락된 분모의 변화율은 계산하지 않는다.

## 기능·RTL

- 폭·signedness·truncation·overflow·priority·latch·reset·FSM·handshake/backpressure·FIFO 경계를 명세와 연결해 확인한다.
- clock/reset crossing은 구조와 프로토콜로 검토한다. 여러 비트를 각각 2-FF 동기화했다고 bus coherence가 보장되는 것은 아니다. FIFO·handshake·Gray encoding 등은 실제 사용 조건에 맞게 선택한다.
- testbench가 DUT와 같은 잘못된 가정을 공유하는지 살핀다. nominal pass에 그치지 않고 문제를 드러낼 수 있는 경계·부하·backpressure·reset 조건을 고른다.
- lint 또는 simulation이 CDC·timing·모든 합법 입력의 기능을 증명했다고 해석하지 않는다. formal 결과는 parameter·assumption·depth·reachable/cover 결과를 확인한다.

## STA·SDC

- 먼저 clock 정의·generated clock·I/O delay·exceptions·propagated/ideal clock·unconstrained endpoint를 확인한다. 조건 누락에서 생긴 깨끗한 숫자를 설계 개선으로 보지 않는다.
- mode/corner/clock group별 setup·hold·WNS·TNS·위반 endpoint 수와 주요 path를 본다. arrival/required time은 해당 report 정의에 따라 읽는다. 일반적인 setup slack은 required−arrival, hold slack은 arrival−required이며 check-specific 정의와 edge 관계를 우선한다.
- cell/net delay, fanout/slew/capacitance, launch/capture clock latency, skew와 uncertainty로 원인을 분해한다. 배선 지배와 논리 지배의 대안을 구분한다.
- multicycle을 일반적인 동일 clock N-cycle setup과 원래 hold 관계 복원에 사용하는 경우 보통 setup N / hold N−1이다. 무조건 hold 1을 넣지 않는다. 기능적 clock-enable, 위상·clock ratio, start/end와 tool semantics를 확인한다.
- 주파수 완화는 setup budget을 늘릴 수 있으나 hold closure의 보편적인 해결책은 아니다. hold delay 보정이 setup을 악화시키는지, setup 가속이 hold를 악화시키는지 함께 확인한다.
- "SS high temperature가 언제나 최악" 같은 고정 기준을 사용하지 않는다. library와 signoff matrix의 온도 역전·RC·OCV 조건을 따른다.

## PPA·물리설계

- 입력·workload·activity·frequency·voltage·corner·도구 버전·분석 단계가 동일하거나 차이가 통제된 비교인지 확인한다. 무작위 실험은 동일 seed의 짝지은 비교 또는 반복 실험 분포 등 적합한 설계를 사용한다. 통제되지 않은 차이가 있으면 설계 변경만의 개선 효과라고 주장하지 않는다.
- cell count 감소는 면적·전력 개선의 충분조건이 아니다. buffer·cell size·Vt·clock load·routing과 실제 mapped/post-route 값을 확인한다.
- clock gating은 enable 안정성, ICG·DFT·clock 정의를 포함해 검증한다. power gating은 isolation/retention와 wake-up 조건까지 기능 변경으로 취급한다.
- floorplan과 congestion, CTS, IR/EM, DRC/LVS는 주어진 과제에서 필요한 항목을 확인한다. 공정과 무관한 utilization·skew·IR-drop 수치를 pass 기준으로 채택하지 않는다.

## 메모리·아날로그 조건부 분기

SRAM/register file라면 실제 용량·port·latency·동시 접근·read-during-write·bank conflict·ECC·retention·macro view 정합성을 본다. SRAM macro용 스킬을 DRAM/HBM cell·refresh·retention·TSV·package 분석 전문가로 간주하지 않는다.

SPICE/Spectre/추출 넷리스트라면 pin order·model include·bias·W/L·multiplicity·동작점·testbench 자극/부하/측정 정의를 확인한다. 작은 parasitic이나 큰 저항을 일괄 삭제한 넷리스트로 전체 설계의 안정성·누설 경로가 검증됐다고 하지 않는다. 요약 필터는 탐색용이며 실제 검증에는 원본/정당화된 reduction을 쓴다.

## 도구 선택

이미 제공된 도구·프로젝트 실행법을 먼저 사용한다. 가능할 때 RTL lint/simulation, 합성, formal/LEC, STA, P&R, SPICE를 문제에 맞게 조합한다. Verilator·Icarus·Yosys·SymbiYosys·OpenSTA·OpenROAD·ngspice는 후보이며 모두 항상 필요한 것은 아니다. 실제 설치와 frontend 지원·library·PDK 준비 여부를 확인한다. 명령어 이름만 아는 것을 실행 가능 환경으로 취급하지 않는다.

Formal 검토에서는 assume을 하나씩 제거했을 때 반드시 실패해야 한다는 규칙을 쓰지 않는다. antecedent/witness 도달 가능성과 과도한 제약을 확인한다. bounded response 요구와 unbounded liveness를 구분하고, 증명 범위와 엔진 결과를 기록한다. native Yosys 스크립트는 `yosys -s <script.ys>`, Tcl 스크립트는 `yosys -c <script.tcl>`로 구분하되 실제 실행 버전의 help를 확인한다.
