# 메모리와 인접 분야: 분석 수준을 먼저 고르기

메모리 시스템, 컨트롤러 RTL, 메모리 cell 회로, 소자/공정, package/열은 다른 수준이다. 도구 하나의 결과를 다른 수준의 증거로 확대하지 않는다. 출처는 source-map.md를 따른다.

| 대상 | 필요한 입력 예 | 후보 자료 | 말할 수 있는 범위 |
|---|---|---|---|
| DRAM/HBM 시스템 | memory spec, controller, mapping, workload/trace | Ramulator 2.1 [T07,D21], DRAMsim3 [T08] | 모델 내 bandwidth/latency·bank conflict·queue/refresh 관련 병목 탐색 |
| DRAM 전력 | 지원되는 memory spec·command trace·조건 | DRAMPower [T09] | 모델 기반 energy/power 추정; silicon 실측과 구분 |
| SRAM macro | 용량·port·cycle·공정·model views | OpenRAM [T10] | 지원 기술의 SRAM 생성/모델; DRAM cell 대체 아님 |
| NAND/SSD 시스템 | controller/FTL·queue·workload·device config | MQSim [T15,D22], FEMU [T16] | 시스템 지연·처리량 실험; NAND cell 전기 특성 검증 아님 |
| cell/아날로그 | 편집 가능한 netlist·모델·바이어스·TB | ngspice [D15], 안정성/잡음 [D16–D18] | 제공 모델 조건의 DC/AC/transient/noise 등 |
| 소자 | geometry/mesh·material·PDE·boundary·calibration | DEVSIM [T13] | 설정한 소자 모델의 수치 해석 |
| 열 | floorplan·power·열 파라미터·boundary | HotSpot [T14] | 열 모델 조건의 온도 해석; SI/PI/기계 신뢰성 전체 보증 아님 |

## 보고서·실제 수정의 두 경로

그림/보고서만 있으면 보이는 구조, 병목 후보, 추가 확인 방법, 수정 명세까지 작성한다. 숨겨진 연결이나 실제 개선율을 생성하지 않는다.

실행 가능한 데이터가 있으면 기준 조건을 재현하고 최소 변경 후보를 비교한다. 모델·workload·measurement definition과 변경 사항을 기록한다. 다른 simulator끼리 비교할 때 address mapping·종료 조건·timing spec을 맞추지 않으면 같은 문제를 비교한다고 할 수 없다. 결과의 수치 정확도는 검증된 범위까지만 말한다.

실제 SK하이닉스 cell 모델·PDK·제품 내부 자료·과제의 정답은 이번 자료에 포함되지 않는다.
