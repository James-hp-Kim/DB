---
name: setup
description: Set up this semiconductor evidence package in Windows Codex, check Python and database health, and prepare project-local skills and MCP configuration when the user asks to install it.
---

# Windows 설치

복사 설치본에 references/local-paths.md가 있으면 그 파일의 package/runtime 경로를 사용한다. 패키지 루트의 README와 docs/INSTALL-WINDOWS.md를 먼저 읽는다. 플러그인 캐시에 있는 경우 이 스킬 기준 ../../runtime/knowledge.py stats로 DB 상태를 확인할 수 있다. MCP 서버는 ../../runtime/server.py이며 Python 3.12 이상으로 실행한다. 플러그인 단독 캐시에는 ../../guides/INSTALL-WINDOWS.md에도 설치 안내가 있다.

설치를 요청받으면 패키지의 setup.ps1을 사용한다. 기본 workspace 방식은 저장소 안의 .agents/skills와 .codex/config.toml을 만든다. plugin 방식은 스킬 설치를 플러그인 관리자에 맡기고 프로젝트 MCP 설정만 준비한다. 두 방식을 겹쳐 설치하지 않는다. 기존 설정이 있으면 생성된 조각을 병합하고 동명 MCP를 중복 등록하지 않는다. 사용자 전역 설정과 시스템 PATH를 임의 교체하지 않는다.

자료 검색은 EDA 설치 없이 된다. 시뮬레이션을 요청받았을 때만 별도 도구를 설치하고 테스트를 실행한다. 설정 파일 생성, MCP 응답, Codex에서 도구를 실제 사용한 상태를 구분해 보고한다.
