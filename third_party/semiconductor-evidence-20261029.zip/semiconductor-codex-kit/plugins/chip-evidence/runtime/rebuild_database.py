"""Rebuild a local SQLite index from reviewable JSONL. Writes only package data."""
from pathlib import Path
import json, sqlite3, os
ROOT=Path(__file__).resolve().parents[1]
def rebuild():
    target=ROOT/'data/knowledge.sqlite';temp=target.with_suffix('.building')
    if temp.exists(): raise SystemExit('A prior .building file exists. Inspect it before retrying.')
    con=sqlite3.connect(temp)
    con.executescript('''CREATE TABLE records(id TEXT PRIMARY KEY,kind TEXT,title TEXT,status TEXT,url TEXT,path TEXT,line_start INTEGER,line_end INTEGER,sha256 TEXT,related_claims TEXT,content TEXT);
    CREATE VIRTUAL TABLE search_index USING fts5(title,content,content=records,content_rowid=rowid,tokenize='unicode61');''')
    with (ROOT/'data/records.jsonl').open(encoding='utf-8') as f:
        for line in f:
            row=json.loads(line)
            vals=[row.get(k) for k in ['id','kind','title','status','url','path','line_start','line_end','sha256']]
            con.execute('INSERT INTO records VALUES(?,?,?,?,?,?,?,?,?,?,?)',vals+[json.dumps(row.get('related_claims',[])),row['content']])
    con.execute("INSERT INTO search_index(search_index) VALUES('rebuild')")
    con.commit()
    assert con.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
    count=con.execute('SELECT count(*) FROM records').fetchone()[0]
    con.close();os.replace(temp,target)
    print(json.dumps({'records':count,'database':str(target)}))
if __name__=='__main__': rebuild()
