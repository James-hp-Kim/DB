`timescale 1ns/1ps
module bench;
 parameter BARREL=0, TWO_STAGE=1, DUALPORT=1;
 reg clk=0,resetn=0; always #5 clk=~clk;
 wire trap,valid,instr;wire [31:0] addr,wdata;wire [3:0] strb;
 reg ready=0;reg [31:0] rdata=0;
 picorv32 #(.BARREL_SHIFTER(BARREL),.TWO_STAGE_SHIFT(TWO_STAGE),.ENABLE_REGS_DUALPORT(DUALPORT)) dut(
 .clk(clk),.resetn(resetn),.trap(trap),.mem_valid(valid),.mem_instr(instr),.mem_ready(ready),.mem_addr(addr),.mem_wdata(wdata),.mem_wstrb(strb),.mem_rdata(rdata),
 .pcpi_wr(1'b0),.pcpi_rd(32'b0),.pcpi_wait(1'b0),.pcpi_ready(1'b0),.irq(32'b0));
 reg [31:0] mem[0:16383],gold[0:1023];
 reg [2047:0] program_file,gold_file;
 integer n,i,wait_cycles=0,waited=0,cycles=0,errors=0,writes=0;
 initial begin
   if (!$value$plusargs("program=%s",program_file)) $fatal(1,"program missing");
   if (!$value$plusargs("gold=%s",gold_file)) $fatal(1,"gold missing");
   if (!$value$plusargs("n=%d",n)) $fatal(1,"n missing");
   if (!$value$plusargs("wait=%d",wait_cycles)) wait_cycles=0;
   for(i=0;i<16384;i=i+1)mem[i]=0;
   for(i=4096;i<5120;i=i+1)mem[i]=32'hdeadc0de;
   $readmemh(program_file,mem);$readmemh(gold_file,gold,0,n-1);
   repeat(10)@(negedge clk);resetn=1;
 end
 always @(posedge clk) begin
   ready<=0;
   if(resetn)begin
     cycles<=cycles+1;
     if(trap)begin $display("RESULT FAIL trap cycles=%0d",cycles);$finish;end
     if(cycles>200000)begin $display("RESULT FAIL timeout cycles=%0d",cycles);$finish;end
     if(valid&&!ready)begin
       if(waited<wait_cycles)waited<=waited+1;
       else begin
         waited<=0;ready<=1;
         if(addr==32'h10000000 && strb==4'b1111)begin
           for(i=0;i<n;i=i+1) if(mem[4096+i]!==gold[i])begin
             if(errors<5)$display("MISMATCH word=%0d actual=%08x expected=%08x",i,mem[4096+i],gold[i]);
             errors=errors+1;
           end
           if(errors==0 && writes==n)$display("RESULT PASS cycles=%0d words=%0d",cycles,n);
           else $display("RESULT FAIL cycles=%0d errors=%0d writes=%0d expected_writes=%0d",cycles,errors,writes,n);
           $finish;
         end else if(addr<65536)begin
           rdata<=mem[addr>>2];
           if(strb[0])mem[addr>>2][7:0]<=wdata[7:0];
           if(strb[1])mem[addr>>2][15:8]<=wdata[15:8];
           if(strb[2])mem[addr>>2][23:16]<=wdata[23:16];
           if(strb[3])mem[addr>>2][31:24]<=wdata[31:24];
           if(|strb && addr>=16384 && addr<20480)writes<=writes+1;
         end else begin $display("RESULT FAIL bad-address addr=%08x cycles=%0d",addr,cycles);$finish;end
       end
     end
   end
 end
endmodule
