module proof(input [3:0] a, output [3:0] y); assign y=a+4'd0; always @* begin assume(a<4'd5); assert(y==a); end endmodule
