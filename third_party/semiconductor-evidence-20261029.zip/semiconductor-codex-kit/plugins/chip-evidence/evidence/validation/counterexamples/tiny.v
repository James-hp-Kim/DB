module tiny(input [3:0] a, output [3:0] y); assign y=a+4'd0; endmodule
