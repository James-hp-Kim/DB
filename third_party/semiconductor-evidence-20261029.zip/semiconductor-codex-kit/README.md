# Semiconductor Codex Kit — Windows

공개 반도체 자료와 교정 사항을 찾아 근거와 함께 답변하고, 공개 RTL 실험을 재현하는 **Codex용 자료·스킬·MCP 패키지**입니다. GitHub 업로드 전 로컬 배포본입니다. 모델을 재학습한 파일이나 범용 반도체 전문가 인증 제품이 아닙니다.

## 처음 사용하는 순서

1. 이 폴더를 향후 GitHub 저장소 루트로 사용합니다. `.agents`와 플러그인 안의 `.codex-plugin`도 포함합니다. 현재 업로드는 수행하지 않았습니다.
2. 새 Windows PC에서 Codex와 Python 3.12 이상을 준비합니다. Git은 선택입니다. GitHub **Code → Download ZIP**으로 받아 압축을 풀어도 됩니다.
3. Codex에서 압축 푼 이 폴더를 프로젝트로 엽니다. Codex에 아래 문장을 입력합니다.

> 이 저장소의 AGENTS.md와 docs/INSTALL-WINDOWS.md를 읽고 setup.ps1로 workspace 설치를 진행해줘. 설치 후 데이터베이스 상태와 MCP 검색을 확인하고, 홀드 슬랙 교정 기록 C06을 원문 근거와 함께 찾아줘.

기본 설치는 **이 프로젝트 안의 스킬과 MCP 설정**만 준비합니다. 그 뒤 Codex를 다시 열어 도구 연결을 확인합니다. 어느 프로젝트에서나 쓰려면 아래 설치 문서의 전역 연결 절차 또는 플러그인 방식을 선택합니다.

## 원하는 것에 따라 필요한 구성

|목적|필요한 것|별도로 필요하지 않은 것|
|---|---|---|
|GitHub에서 자료 읽기|브라우저 또는 Codex GitHub 연결|Python, EDA|
|Codex로 로컬 DB 검색|Codex + Python 3.12+ + 다운로드한 이 폴더|별도 API 키, pip 라이브러리, 클라우드 DB|
|자연어 질문에서 MCP 검색 사용|위 구성 + 프로젝트 MCP 설정 + 재시작|Node.js, Docker, WSL|
|스킬/플러그인 사용|workspace 스킬 설치 또는 플러그인 설치 중 하나|다른 AI 클라이언트|
|이번 PicoRV32 실험 재실행|위 구성 + Windows OSS CAD Suite|PDK, 상업 EDA, WSL|
|실제 타이밍·전력·물리 분석|해당 설계·제약·라이브러리·PDK·적합한 EDA|이 패키지만으로 대체 불가|

Python은 이 패키지의 도구 실행 환경일 뿐, 사용자는 Codex에 질문하면 됩니다. DB 검색은 로컬에서 동작하며 추가 API 호출을 하지 않습니다. Codex 자체 사용은 계정과 서비스 연결이 필요합니다.

## 들어 있는 것

- `plugins/chip-evidence/skills/`: 설계 검토, 근거 검색, 설치 안내 스킬 3개.
- `plugins/chip-evidence/runtime/`: 읽기 전용 MCP 서버, 직접 검색 도구, SQLite 재생성 도구.
- `plugins/chip-evidence/data/`: 검색 DB와 사람이 검토 가능한 JSONL 원장.
- `plugins/chip-evidence/evidence/`: 48개 자료 카탈로그, 40개 주장 검토, 62개 GitHub 선택 원문 파일, PDF 2개, 실제 실험 결과와 로그.
- `.agents/plugins/marketplace.json`: Codex에서 로컬 플러그인으로 설치할 때 쓸 카탈로그.
- `scripts/`: 설정 생성, 무결성 점검, 선택 EDA 다운로드, 실험 재실행 및 패키지 시험.
- `docs/VALIDATION.md`: 검증의 실제 결과·분모·범위.

원문 파일은 자동 실행 스킬로 등록하지 않았습니다. 오류가 있는 원문은 검토 기록과 연결되어 있으며, 실제 사용 스킬은 별도로 교정한 절차입니다. PDF 2개는 원본 열람용이고 DB가 PDF의 전체 본문을 검색하지는 않습니다. 저장소 전체와 외부 링크의 모든 페이지를 다운로드한 것은 아닙니다.

## 바로 할 수 있는 질문

- “홀드 슬랙 계산식과 공개 스킬의 오류를 근거로 설명해줘.”
- “HBM 병목과 DRAM 셀 분석에 필요한 자료가 어떻게 달라?”
- “PicoRV32에서 실제 측정한 성능·셀 수 절충 결과를 찾아줘.”
- “이 회로도에서 확정 가능한 문제와 추가 자료가 필요한 가설을 나눠줘.”
- “첨부 RTL의 문제를 찾아 최소 변경안과 구조 변경안을 비교하고, 실행 가능한 시험으로 검증해줘.”

## 확인된 범위

정상 설정 시험 **144/144**, 알려진 주입 결함 **6/6 탐지**, 복구 확인 **12/12**. 배럴 시프터 설정은 이번 부하의 총 사이클 **4.05% 감소**. 이것은 전체 칩 진단 정확도나 실제 실리콘 PPA 개선율이 아닙니다. 원문 전체가 정확하다는 주장은 발견한 반례로 성립하지 않습니다.

세부 문서: [Windows 설치](docs/INSTALL-WINDOWS.md) · [검증 결과](docs/VALIDATION.md) · [데이터 구조·갱신](docs/DATABASE.md) · [배포·권리](THIRD_PARTY_NOTICES.md) · [패키지 시험](docs/PACKAGE-TESTS.md)
