from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[1]
SKIP={'.local','.tools','work','__pycache__','.git','.codex'}
def included(path):
    rel=path.relative_to(ROOT)
    return not any(x in SKIP for x in rel.parts) and not rel.as_posix().startswith('.agents/skills/') and path.name!='MANIFEST.json' and path.suffix not in ['.pyc','.building']
def main():
    rows=[{'path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(ROOT.rglob('*')) if p.is_file() and included(p)]
    (ROOT/'MANIFEST.json').write_text(json.dumps({'snapshot':'2026-10-29','files':rows},ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'files':len(rows),'bytes':sum(r['bytes'] for r in rows)}))
if __name__=='__main__':main()
