from pathlib import Path
import sys,json,hashlib
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'plugins/chip-evidence/runtime'))
from knowledge import stats
def main():
    issues=[];checked=0
    if sys.version_info<(3,12):issues.append('Python 3.12+ required')
    for r in json.loads((ROOT/'MANIFEST.json').read_text(encoding='utf-8'))['files']:
        f=ROOT/r['path']
        if not f.is_file() or hashlib.sha256(f.read_bytes()).hexdigest()!=r['sha256']:issues.append('Missing or modified: '+r['path'])
        checked+=1
    status=stats()
    if status['database_check']!='ok':issues.append('Database integrity failed')
    print(json.dumps({'status':'PASS' if not issues else 'FAIL','python':sys.version,'files_checked':checked,'database':status,'issues':issues,'not_checked':['Codex UI skill discovery','Codex MCP connection','EDA binaries and PDK']},ensure_ascii=False,indent=2))
    return bool(issues)
if __name__=='__main__':sys.exit(main())
