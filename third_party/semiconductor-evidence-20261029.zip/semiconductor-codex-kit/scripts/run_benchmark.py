from pathlib import Path
from datetime import datetime, timezone
import os, subprocess, json, hashlib, random, shutil, re, time

import argparse
parser=argparse.ArgumentParser()
parser.add_argument('--eda-root',type=Path,required=True)
parser.add_argument('--output',type=Path,required=True)
args=parser.parse_args()
ROOT=Path(__file__).resolve().parents[1]
OUT=args.output.resolve()
if OUT.exists(): raise SystemExit('Output folder already exists. Choose a new folder to preserve evidence.')
BIN=args.eda_root.resolve()/'bin'
ENV=os.environ.copy();ENV['PATH']=str(BIN)+os.pathsep+str(BIN.parent/'lib')+os.pathsep+ENV['PATH']
for d in ['rtl','tests','logs','build','synthesis','provenance']: (OUT/d).mkdir(parents=True,exist_ok=True)
SRC=ROOT/'plugins/chip-evidence/evidence/references/sources/YosysHQ/picorv32'
original=(SRC/'picorv32.v').read_text(encoding='utf-8')
shutil.copyfile(SRC/'picorv32.v',OUT/'rtl/original.v')
shutil.copyfile(SRC/'COPYING',OUT/'rtl/COPYING')
shutil.copyfile(SRC/'README.md',OUT/'rtl/upstream-README.md')
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(args, log, timeout=120):
    started=time.monotonic()
    p=subprocess.run([str(x) for x in args],cwd=OUT,env=ENV,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=timeout)
    (OUT/'logs'/log).write_text('COMMAND '+json.dumps([str(x) for x in args])+'\n'+p.stdout+p.stderr,encoding='utf-8')
    return p,round(time.monotonic()-started,3)

versions={}
for tool,arg in [('iverilog','-V'),('vvp','-V'),('yosys','-V')]:
    p,_=run([BIN/(tool+'.exe'),arg],tool+'-version.log');assert p.returncode==0,p.stderr
    versions[tool]=(p.stdout+p.stderr).splitlines()[0]
(OUT/'provenance/tools.json').write_text(json.dumps(versions,indent=2),encoding='utf-8')

MASK=0xffffffff
def signed(v):return v-(1<<32) if v&(1<<31) else v
def enc_i(rd,rs1,imm,f3=0,opcode=0x13):return ((imm&4095)<<20)|(rs1<<15)|(f3<<12)|(rd<<7)|opcode
def enc_r(rd,rs1,rs2,f3,f7=0):return (f7<<25)|(rs2<<20)|(rs1<<15)|(f3<<12)|(rd<<7)|0x33
def enc_s(rs1,rs2,imm=0,f3=2):return (((imm&4095)>>5)<<25)|(rs2<<20)|(rs1<<15)|(f3<<12)|((imm&31)<<7)|0x23
def enc_b(rs1,rs2,offset,f3):
    v=offset&8191
    return ((v>>12)<<31)|(((v>>5)&63)<<25)|(rs2<<20)|(rs1<<15)|(f3<<12)|(((v>>1)&15)<<8)|(((v>>11)&1)<<7)|0x63
OPS={'add':(0,0),'sub':(0,32),'sll':(1,0),'slt':(2,0),'sltu':(3,0),'xor':(4,0),'srl':(5,0),'sra':(5,32),'or':(6,0),'and':(7,0)}
def calc(op,a,b):
    return {'add':lambda:a+b,'sub':lambda:a-b,'sll':lambda:a<<(b&31),'slt':lambda:int(signed(a)<signed(b)),'sltu':lambda:int(a<b),'xor':lambda:a^b,'srl':lambda:a>>(b&31),'sra':lambda:signed(a)>>(b&31),'or':lambda:a|b,'and':lambda:a&b}[op]()&MASK
# Independent hand-calculated checks of encoding and arithmetic corner cases.
assert enc_i(1,0,1020)==0x3fc00093 and enc_s(1,0)==0x0000a023
assert enc_r(3,1,2,0)==0x002081b3
assert calc('sub',0,1)==MASK and calc('sra',0x80000000,31)==MASK
assert calc('slt',MASK,0)==1 and calc('sltu',MASK,0)==0

def make_program(name,operations,branches=False,loads=False):
    words=[];expected=[];desc=[]
    def li(reg,v):
        v &= MASK; upper=((v+2048)>>12)&0xfffff
        words.extend([(upper<<12)|(reg<<7)|0x37,enc_i(reg,reg,v&4095)])
    li(30,0x4000)
    def record(value,label):
        words.extend([enc_s(30,3),enc_i(30,30,4)])
        expected.append(value&MASK);desc.append(label)
    for op,a,b in operations:
        li(1,a);li(2,b);f3,f7=OPS[op];words.append(enc_r(3,1,2,f3,f7))
        record(calc(op,a&MASK,b&MASK),dict(op=op,a=a&MASK,b=b&MASK))
    if branches:
        for f3 in [0,1,4,5,6,7]:
            for a,b in [(MASK,1),(1,MASK),(7,7)]:
                li(1,a);li(2,b);words.append(enc_i(3,0,11));words.append(enc_b(1,2,8,f3));words.append(enc_i(3,0,22))
                taken={0:a==b,1:a!=b,4:signed(a)<signed(b),5:signed(a)>=signed(b),6:a<b,7:a>=b}[f3]
                record(11 if taken else 22,dict(branch=f3,a=a,b=b))
    if loads:
        li(1,0x3000)
        for f3,off,value in [(0,0,0xffffff80),(4,0,0x80),(0,1,0xfffffffe),(4,1,0xfe),(1,0,0xfffffe80),(5,0,0xfe80),(2,0,0x80fffe80)]:
            words.append(enc_i(3,1,off,f3,0x03));record(value,dict(load=f3,offset=off))
    li(31,0x10000000);words.append(enc_s(31,0));words.append(0x0000006f)
    assert len(words)*4<0x3000 and len(expected)<1024
    (OUT/'tests'/f'{name}.hex').write_text('\n'.join(f'{w:08x}' for w in words)+'\n@00000c00\n80fffe80\n',encoding='ascii')
    (OUT/'tests'/f'{name}.expected').write_text('\n'.join(f'{w:08x}' for w in expected)+'\n',encoding='ascii')
    (OUT/'tests'/f'{name}.vectors.json').write_text(json.dumps(desc,indent=2),encoding='utf-8')
    return dict(name=name,signature_words=len(expected),static_instructions=len(words),program_sha256=digest(OUT/'tests'/f'{name}.hex'))

programs=[]
edges=[0,1,31,32,0x7fffffff,0x80000000,MASK,0xaaaaaaaa]
programs.append(make_program('directed',[(op,a,b) for op in OPS for a,b in zip(edges,edges[::-1])],True,True))
programs.append(make_program('arithmetic_control',[(op,a,b) for op in ['add','sub','xor','or','and'] for a,b in zip(edges,edges[::-1])]))
for seed in range(8):
    rng=random.Random(29000+seed)
    programs.append(make_program(f'mixed_{seed}',[(rng.choice(list(OPS)),rng.getrandbits(32),rng.getrandbits(32)) for _ in range(96)]))
    programs.append(make_program(f'shift_{seed}',[(rng.choice(['sll','srl','sra']),rng.getrandbits(32),rng.choice([0,1,4,7,16,24,31])) for _ in range(96)]))
configs={'baseline':{'BARREL':0,'TWO_STAGE':1,'DUALPORT':1},'barrel':{'BARREL':1,'TWO_STAGE':1,'DUALPORT':1},'compact_shift':{'BARREL':0,'TWO_STAGE':0,'DUALPORT':1},'single_port':{'BARREL':0,'TWO_STAGE':1,'DUALPORT':0}}
mutations=[
 ('M01_sub_as_add','instr_sub ? reg_op1 - reg_op2 : reg_op1 + reg_op2','instr_sub ? reg_op1 + reg_op2 : reg_op1 + reg_op2','SUB subtraction incorrectly replaced by addition'),
 ('M02_signed_compare','$signed(reg_op1) < $signed(reg_op2)','reg_op1 < reg_op2','Signed less-than incorrectly uses unsigned comparison'),
 ('M03_and_as_or','alu_out = reg_op1 & reg_op2;','alu_out = reg_op1 | reg_op2;','AND decoded datapath incorrectly computes OR'),
 ('M04_or_as_xor','alu_out = reg_op1 | reg_op2;','alu_out = reg_op1 ^ reg_op2;','OR decoded datapath incorrectly computes XOR'),
 ('M05_shift_sign','$signed(reg_op1) >>>','reg_op1 >>','Iterative arithmetic right shift loses sign extension'),
 ('M06_load_sign','latched_is_lb: reg_out <= $signed(mem_rdata_word[7:0]);','latched_is_lb: reg_out <= {24\'b0,mem_rdata_word[7:0]};','Signed byte load incorrectly zero extends')
]
mutation_meta=[]
for name,old,new,reason in mutations:
    assert old in original,name
    altered=original.replace(old,new)
    (OUT/'rtl'/f'{name}.v').write_text(altered,encoding='utf-8')
    # Restore only this known change; normalize text as read_text did for comparison.
    repaired_lines=altered.splitlines(keepends=True)
    changed_lines=[i for i,line in enumerate(original.splitlines(keepends=True)) if old in line]
    for i in changed_lines:
        repaired_lines[i]=repaired_lines[i].replace(new,old)
    repaired=''.join(repaired_lines)
    assert repaired==original,name
    (OUT/'rtl'/f'{name}_repaired.v').write_text(repaired,encoding='utf-8')
    mutation_meta.append(dict(name=name,reason=reason,old=old,new=new,occurrences=original.count(old),repaired_text_equals_original=True))
protocol={'created_utc':datetime.now(timezone.utc).isoformat(),'design':'PicoRV32 native memory-interface core','source_commit':'ef203c2b0a3fb793280f5114941416c425c5b461','programs':programs,'configs':configs,'memory_wait_cycles':[0,3],'mutation_cases':mutation_meta,'acceptance':'Every observed signature word must match; no trap/timeout; optimization must preserve tested outputs. Generic cell count is a proxy, not physical area.','bias':'Author-generated non-blind tests and known injected mutations; NOT an independent diagnostic-accuracy benchmark or skill/no-skill A/B test.','not_covered':['all RV32I instructions','formal CPU equivalence','physical timing/power','analog','memory cells','fabricated silicon']}
(OUT/'protocol.json').write_text(json.dumps(protocol,indent=2),encoding='utf-8')

TB=r'''`timescale 1ns/1ps
module bench;
 parameter BARREL=0, TWO_STAGE=1, DUALPORT=1;
 reg clk=0,resetn=0; always #5 clk=~clk;
 wire trap,valid,instr;wire [31:0] addr,wdata;wire [3:0] strb;
 reg ready=0;reg [31:0] rdata=0;
 picorv32 #(.BARREL_SHIFTER(BARREL),.TWO_STAGE_SHIFT(TWO_STAGE),.ENABLE_REGS_DUALPORT(DUALPORT)) dut(
 .clk(clk),.resetn(resetn),.trap(trap),.mem_valid(valid),.mem_instr(instr),.mem_ready(ready),.mem_addr(addr),.mem_wdata(wdata),.mem_wstrb(strb),.mem_rdata(rdata),
 .pcpi_wr(1'b0),.pcpi_rd(32'b0),.pcpi_wait(1'b0),.pcpi_ready(1'b0),.irq(32'b0));
 reg [31:0] mem[0:16383],gold[0:1023];
 reg [2047:0] program_file,gold_file;
 integer n,i,wait_cycles=0,waited=0,cycles=0,errors=0,writes=0;
 initial begin
   if (!$value$plusargs("program=%s",program_file)) $fatal(1,"program missing");
   if (!$value$plusargs("gold=%s",gold_file)) $fatal(1,"gold missing");
   if (!$value$plusargs("n=%d",n)) $fatal(1,"n missing");
   if (!$value$plusargs("wait=%d",wait_cycles)) wait_cycles=0;
   for(i=0;i<16384;i=i+1)mem[i]=0;
   for(i=4096;i<5120;i=i+1)mem[i]=32'hdeadc0de;
   $readmemh(program_file,mem);$readmemh(gold_file,gold,0,n-1);
   repeat(10)@(negedge clk);resetn=1;
 end
 always @(posedge clk) begin
   ready<=0;
   if(resetn)begin
     cycles<=cycles+1;
     if(trap)begin $display("RESULT FAIL trap cycles=%0d",cycles);$finish;end
     if(cycles>200000)begin $display("RESULT FAIL timeout cycles=%0d",cycles);$finish;end
     if(valid&&!ready)begin
       if(waited<wait_cycles)waited<=waited+1;
       else begin
         waited<=0;ready<=1;
         if(addr==32'h10000000 && strb==4'b1111)begin
           for(i=0;i<n;i=i+1) if(mem[4096+i]!==gold[i])begin
             if(errors<5)$display("MISMATCH word=%0d actual=%08x expected=%08x",i,mem[4096+i],gold[i]);
             errors=errors+1;
           end
           if(errors==0 && writes==n)$display("RESULT PASS cycles=%0d words=%0d",cycles,n);
           else $display("RESULT FAIL cycles=%0d errors=%0d writes=%0d expected_writes=%0d",cycles,errors,writes,n);
           $finish;
         end else if(addr<65536)begin
           rdata<=mem[addr>>2];
           if(strb[0])mem[addr>>2][7:0]<=wdata[7:0];
           if(strb[1])mem[addr>>2][15:8]<=wdata[15:8];
           if(strb[2])mem[addr>>2][23:16]<=wdata[23:16];
           if(strb[3])mem[addr>>2][31:24]<=wdata[31:24];
           if(|strb && addr>=16384 && addr<20480)writes<=writes+1;
         end else begin $display("RESULT FAIL bad-address addr=%08x cycles=%0d",addr,cycles);$finish;end
       end
     end
   end
 end
endmodule
'''
(OUT/'tests/bench.v').write_text(TB,encoding='ascii')
def compile_design(name,rtl,params):
    cmd=[BIN/'iverilog.exe','-g2012','-s','bench','-o',f'build/{name}.vvp']
    cmd += [f'-Pbench.{k}={v}' for k,v in params.items()]
    p,_=run(cmd+['tests/bench.v',rtl],name+'-compile.log');assert p.returncode==0,p.stderr
def simulate(name,program,wait):
    log=f"{name}-{program['name']}-w{wait}.log"
    p,sec=run([BIN/'vvp.exe',f'build/{name}.vvp',f"+program=tests/{program['name']}.hex",f"+gold=tests/{program['name']}.expected",f"+n={program['signature_words']}",f'+wait={wait}'],log,30)
    m=re.search(r'RESULT (PASS|FAIL)([^\r\n]*)',p.stdout)
    assert p.returncode==0 and m is not None,(log,p.stdout,p.stderr)
    cycles=re.search(r'cycles=(\d+)',m.group(2))
    return dict(variant=name,program=program['name'],wait=wait,status=m.group(1),cycles=int(cycles.group(1)) if cycles else None,seconds=sec,log='logs/'+log)
results=[]
for name,params in configs.items():
    compile_design(name,'rtl/original.v',params)
    subset=[simulate(name,p,w) for p in programs for w in [0,3]];results+=subset
    print(name,CounterLike:={s:sum(x['status']==s for x in subset) for s in ['PASS','FAIL']},flush=True)
    (OUT/'simulation-results.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
    assert all(x['status']=='PASS' for x in subset),'Baseline/candidate behavior failed; investigate harness or design before continuing'
for name,old,new,reason in mutations:
    compile_design(name,f'rtl/{name}.v',configs['baseline'])
    subset=[simulate(name,p,w) for p in programs for w in [0,3]];results+=subset
    print(name,{s:sum(x['status']==s for x in subset) for s in ['PASS','FAIL']},flush=True)
    fixed=name+'_repaired';compile_design(fixed,f'rtl/{fixed}.v',configs['baseline'])
    results.extend(simulate(fixed,programs[0],w) for w in [0,3])
    (OUT/'simulation-results.json').write_text(json.dumps(results,indent=2),encoding='utf-8')

# Target-neutral synthesis: counts of generic cells only, deliberately no nanometer/area/power claim.
synthesis=[]
for name,params in configs.items():
    script='read_verilog rtl/original.v\n'
    for param,value in [('BARREL_SHIFTER',params['BARREL']),('TWO_STAGE_SHIFT',params['TWO_STAGE']),('ENABLE_REGS_DUALPORT',params['DUALPORT'])]:
        script+=f'chparam -set {param} {value} picorv32\n'
    script+=f'synth -top picorv32\ntee -o synthesis/{name}.json stat -json\n'
    (OUT/'synthesis'/f'{name}.ys').write_text(script,encoding='ascii')
    p,sec=run([BIN/'yosys.exe','-s',f'synthesis/{name}.ys'],name+'-synthesis.log',180)
    assert p.returncode==0,p.stderr
    j=json.loads((OUT/'synthesis'/f'{name}.json').read_text())
    synthesis.append(dict(variant=name,seconds=sec,statistics=j))
    print('Synthesis '+name+' completed',flush=True)
(OUT/'synthesis-results.json').write_text(json.dumps(synthesis,indent=2),encoding='utf-8')
print('Simulation and synthesis complete',flush=True)
