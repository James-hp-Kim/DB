from pathlib import Path
import sys, argparse, json, shutil, hashlib
ROOT=Path(__file__).resolve().parents[1];P=ROOT/'plugins/chip-evidence'
sys.path.insert(0,str(P/'runtime'))
from knowledge import stats

def configure(mode):
    if sys.version_info < (3,12): raise SystemExit('Python 3.12+ required')
    status=stats();assert status['database_check']=='ok'
    local=ROOT/'.local';local.mkdir(exist_ok=True)
    created=[];pending=[]
    if mode=='workspace':
        for source in (P/'skills').iterdir():
            if not source.is_dir(): continue
            dest=ROOT/'.agents/skills'/source.name
            for f in source.rglob('*'):
                if not f.is_file():continue
                target=dest/f.relative_to(source)
                if target.exists() and target.read_bytes()!=f.read_bytes(): raise SystemExit(f'Skill conflict; existing file preserved: {target}')
            shutil.copytree(source,dest,dirs_exist_ok=True);created.append(str(dest.relative_to(ROOT)))
            ref=dest/'references/local-paths.md';ref.parent.mkdir(parents=True,exist_ok=True)
            ref.write_text(f'# Local runtime\n\nDatabase CLI: `{P / "runtime/knowledge.py"}`\nMCP server: `{P / "runtime/server.py"}`\nPackage: `{ROOT}`\n',encoding='utf-8')
    # JSON basic string escaping is compatible with TOML for these absolute paths.
    config='[mcp_servers.chip_evidence]\ncommand = '+json.dumps(sys.executable)+'\nargs = '+json.dumps(['-X','utf8',str(P/'runtime/server.py')])+'\nstartup_timeout_sec = 15\ntool_timeout_sec = 30\n'
    fragment=local/'mcp-config.toml';fragment.write_text(config,encoding='utf-8')
    dest=ROOT/'.codex/config.toml'
    if not dest.exists():
        dest.parent.mkdir(exist_ok=True);dest.write_text(config,encoding='utf-8');created.append('.codex/config.toml')
    elif dest.read_text(encoding='utf-8')!=config: pending.append('Merge .local/mcp-config.toml into existing .codex/config.toml; existing config was preserved.')
    result={'mode':mode,'created_or_verified':created,'pending':pending,'database':status,'next':'Reopen this trusted project in Codex and call knowledge_status / search_evidence. Config creation is not connection verification.'}
    (local/'setup-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--mode',choices=['workspace','plugin'],default='workspace')
    configure(parser.parse_args().mode)
