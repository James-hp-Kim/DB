from pathlib import Path
import subprocess, os, json, re, hashlib
import argparse
parser=argparse.ArgumentParser();parser.add_argument('--eda-root',type=Path,required=True);parser.add_argument('--output',type=Path,required=True)
args=parser.parse_args();ROOT=Path(__file__).resolve().parents[1];OUT=args.output.resolve();BIN=args.eda_root.resolve()/'bin'
if not (OUT/'simulation-results.json').is_file(): raise SystemExit('Run benchmark first in the same output folder.')
import shutil
shutil.copy2(ROOT/'plugins/chip-evidence/evidence/validation/tests/upstream-testbench_ez.v',OUT/'tests/upstream-testbench_ez.v')
env=os.environ.copy();env['PATH']=str(BIN)+os.pathsep+str(BIN.parent/'lib')+os.pathsep+env['PATH']
extra=OUT/'counterexamples';extra.mkdir(exist_ok=True)
def run(args,name):
 p=subprocess.run([str(x) for x in args],cwd=OUT,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=60)
 (OUT/'logs'/name).write_text('COMMAND '+json.dumps([str(x) for x in args])+'\n'+p.stdout+p.stderr,encoding='utf-8')
 return p
(extra/'tiny.v').write_text('module tiny(input [3:0] a, output [3:0] y); assign y=a+4\'d0; endmodule\n')
(extra/'native.ys').write_text('read_verilog counterexamples/tiny.v\nsynth -top tiny\nstat\n')
p=run([BIN/'yosys.exe','-s','counterexamples/native.ys'],'native-script-correct.log');assert p.returncode==0
q=run([BIN/'yosys.exe','-c','counterexamples/native.ys'],'native-script-wrong.log');assert q.returncode!=0 and 'invalid command name' in q.stderr
proof=[]
for assumption in [True,False]:
 name='with_assumption' if assumption else 'without_assumption'
 v="module proof(input [3:0] a, output [3:0] y); assign y=a+4'd0; always @* begin "
 if assumption:v+="assume(a<4'd5); "
 v+='assert(y==a); end endmodule\n'
 (extra/(name+'.v')).write_text(v)
 command=f'read_verilog -formal counterexamples/{name}.v; prep -top proof; chformal -lower; sat -set-assumes -prove-asserts -verify'
 p=run([BIN/'yosys.exe','-p',command],name+'.log');assert p.returncode==0 and 'SUCCESS' in p.stdout
 proof.append(dict(case=name,result='PASS',log='logs/'+name+'.log'))
result={'native_script':{'minus_s_exit':0,'minus_c_exit':q.returncode,'verdict':'-c interprets Tcl; native .ys needs -s'},'assumption_counterexample':proof,'limits':'Small combinational formal counterexample, not a CPU proof or a general vacuity checker.'}
ez=OUT/'tests/upstream-testbench_ez.v'
if ez.exists():
 p=run([BIN/'iverilog.exe','-g2012','-s','testbench','-o','build/upstream.vvp',ez,'rtl/original.v'],'upstream-compile.log');assert p.returncode==0,p.stderr
 p=run([BIN/'vvp.exe','build/upstream.vvp'],'upstream-smoke.log');assert p.returncode==0
 writes=re.findall(r'write\s+0x([0-9a-f]+): 0x([0-9a-f]+) \(wstrb=([01]+)\)',p.stdout)
 assert len(writes)>10 and all(int(a,16)==1020 and int(v,16)==i and s=='1111' for i,(a,v,s) in enumerate(writes))
 result['upstream_smoke']={'status':'PASS','write_count':len(writes),'values':f'0..{len(writes)-1}','address':1020,'check':'Original upstream bench; externally checked sequential counter writes. Limited smoke test.'}
(OUT/'counterexample-results.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
sim=json.loads((OUT/'simulation-results.json').read_text());syn=json.loads((OUT/'synthesis-results.json').read_text());protocol=json.loads((OUT/'protocol.json').read_text())
summary={'design':protocol['design'],'commit':protocol['source_commit'],'total_simulations':len(sim),'configuration_results':[],'mutation_results':[],'repairs':{'passed':sum(x['status']=='PASS' for x in sim if x['variant'].endswith('_repaired')),'total':sum(x['variant'].endswith('_repaired') for x in sim)},'scope':protocol['bias'],'additional_checks':result}
for cfg in protocol['configs']:
 rows=[r for r in sim if r['variant']==cfg]
 cell=next(x['statistics']['design']['num_cells'] for x in syn if x['variant']==cfg)
 groups={g:sum(r['cycles'] for r in rows if g=='all' or r['program'].startswith(g)) for g in ['all','shift','mixed','arithmetic_control','directed']}
 summary['configuration_results'].append({'name':cfg,'passed':sum(r['status']=='PASS' for r in rows),'total':len(rows),'generic_cells':cell,'cycle_sums':groups})
base=summary['configuration_results'][0]
for row in summary['configuration_results']:
 row['cycle_reduction_percent']={k:round(100*(1-v/base['cycle_sums'][k]),3) for k,v in row['cycle_sums'].items()}
 row['cell_change_percent']=round(100*(row['generic_cells']/base['generic_cells']-1),3)
for m in protocol['mutation_cases']:
 rows=[r for r in sim if r['variant']==m['name']]
 summary['mutation_results'].append({'name':m['name'],'reason':m['reason'],'failed_tests':sum(r['status']=='FAIL' for r in rows),'total_tests':len(rows),'detected':any(r['status']=='FAIL' for r in rows)})
(OUT/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps(summary,indent=2))
