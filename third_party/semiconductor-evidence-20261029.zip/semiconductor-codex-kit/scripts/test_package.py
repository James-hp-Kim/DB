"""Behavioral tests: retrieval, protocol, integrity, installer preservation, relocation."""
from pathlib import Path
import json, subprocess, sys, tempfile, shutil, hashlib, unittest, tomllib
ROOT=Path(__file__).resolve().parents[1];P=ROOT/'plugins/chip-evidence'
sys.path.insert(0,str(P/'runtime'))
from knowledge import search,get_record,stats,benchmark_results,connect

class PackageTest(unittest.TestCase):
    def test_korean_retrieval(self):
        self.assertIn('C06',[r['id'] for r in search('홀드 슬랙',10)['results']])
        self.assertIn('C05',[r['id'] for r in search('멀티사이클',10)['results']])
    def test_corrections_and_sources(self):
        r=get_record('C08');self.assertIn('-s',r['content']);self.assertIn('D05',r['related_claims']);self.assertIn('http',r['content'])
    def test_no_evidence_and_invalid_arguments(self):
        self.assertEqual(search('zzznothingfound983741')['results'],[])
        with self.assertRaises(ValueError):search('x',100)
        with self.assertRaises(ValueError):get_record('../../etc/passwd')
    def test_sql_read_only_and_query_safety(self):
        with connect() as con:
            with self.assertRaises(Exception):con.execute('DELETE FROM records')
        self.assertIsInstance(search('" OR 1=1; DROP TABLE records; --'),dict)
        self.assertGreater(stats()['records'],100)
    def test_record_links_and_source_hashes(self):
        ids=set();records=[]
        for line in (P/'data/records.jsonl').read_text(encoding='utf-8').splitlines():records.append(json.loads(line))
        ids={r['id'] for r in records};self.assertEqual(len(ids),len(records))
        for r in records:
            for linked in r['related_claims']:self.assertIn(linked,ids)
            if r['path']:
                f=(P/r['path']).resolve();self.assertTrue(f.is_relative_to(P.resolve()));self.assertTrue(f.is_file(),str(f));self.assertEqual(hashlib.sha256(f.read_bytes()).hexdigest(),r['sha256'])
    def test_measurements_scope(self):
        b=benchmark_results();self.assertEqual(b['total_simulations'],372)
        self.assertEqual(sum(r['total'] for r in b['configuration_results']),144)
        self.assertTrue(all(r['detected'] for r in b['mutation_results']));self.assertEqual(b['repairs']['passed'],12)
        self.assertIn('non-blind',b['scope'])
    def test_plugin_and_skills_paths(self):
        m=json.loads((ROOT/'.agents/plugins/marketplace.json').read_text(encoding='utf-8'));self.assertTrue((ROOT/m['plugins'][0]['source']['path']).is_dir())
        m=json.loads((P/'.codex-plugin/plugin.json').read_text());self.assertTrue((P/m['skills']).is_dir())
        self.assertEqual(len(list((P/'skills').glob('*/SKILL.md'))),3)
    def test_mcp_transport(self):
        messages=[{'jsonrpc':'2.0','id':1,'method':'initialize','params':{'protocolVersion':'2025-11-25','capabilities':{},'clientInfo':{'name':'package-test','version':'1'}}}, {'jsonrpc':'2.0','method':'notifications/initialized'}, {'jsonrpc':'2.0','id':2,'method':'tools/list'}, {'jsonrpc':'2.0','id':3,'method':'tools/call','params':{'name':'search_evidence','arguments':{'query':'홀드 슬랙','limit':8}}}, {'jsonrpc':'2.0','id':4,'method':'tools/call','params':{'name':'get_evidence','arguments':{'record_id':'C06'}}}, {'jsonrpc':'2.0','id':5,'method':'tools/call','params':{'name':'get_evidence','arguments':{'record_id':'missing'}}}, {'jsonrpc':'2.0','id':6,'method':'tools/call','params':{'name':'unknown','arguments':{}}}]
        p=subprocess.run([sys.executable,'-X','utf8',str(P/'runtime/server.py')],input='\n'.join(json.dumps(x,ensure_ascii=False) for x in messages)+'\n',capture_output=True,text=True,encoding='utf-8',timeout=30)
        self.assertEqual(p.returncode,0,p.stderr);responses=[json.loads(l) for l in p.stdout.splitlines()];self.assertEqual(len(responses),6)
        self.assertEqual(len(responses[1]['result']['tools']),4)
        self.assertIn('C06',responses[2]['result']['content'][0]['text']);self.assertTrue(responses[4]['result']['isError']);self.assertEqual(responses[5]['error']['code'],-32602)
    def test_relocation_setup_and_preserve_config(self):
        with tempfile.TemporaryDirectory(prefix='chip-kit-') as tmp:
            dst=Path(tmp)/'한글 공백 경로';shutil.copytree(ROOT,dst,ignore=shutil.ignore_patterns('.local','.tools','work','__pycache__','.git'))
            # Do not let previously generated workspace-local state affect this fixture.
            config=dst/'.codex/config.toml'
            if config.exists():config.unlink()
            script=dst/'scripts/configure.py'
            p=subprocess.run([sys.executable,'-X','utf8',str(script)],capture_output=True,text=True,encoding='utf-8',timeout=30)
            self.assertEqual(p.returncode,0,p.stderr)
            cfg=tomllib.loads(config.read_text(encoding='utf-8'))['mcp_servers']['chip_evidence'];self.assertEqual(cfg['command'],sys.executable);self.assertTrue(Path(cfg['args'][-1]).is_file())
            first=config.read_bytes()
            p=subprocess.run([sys.executable,'-X','utf8',str(script)],capture_output=True,text=True,encoding='utf-8',timeout=30);self.assertEqual(p.returncode,0,p.stderr);self.assertEqual(config.read_bytes(),first)
            custom=b'# existing unrelated settings\nmodel = "keep-me"\n';config.write_bytes(custom)
            p=subprocess.run([sys.executable,'-X','utf8',str(script),'--mode','plugin'],capture_output=True,text=True,encoding='utf-8',timeout=30);self.assertEqual(p.returncode,0,p.stderr);self.assertEqual(config.read_bytes(),custom)
            p=subprocess.run([sys.executable,'-X','utf8',str(dst/'plugins/chip-evidence/runtime/knowledge.py'),'get','C06'],cwd=tmp,capture_output=True,text=True,encoding='utf-8',timeout=30);self.assertEqual(p.returncode,0,p.stderr);self.assertIn('arrival',p.stdout)

if __name__=='__main__':unittest.main(verbosity=2)
