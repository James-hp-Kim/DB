"""Opt-in official Windows binary acquisition, pinned to the measured tool build."""
from pathlib import Path
import argparse, urllib.request, hashlib, tarfile, json, sys
ROOT=Path(__file__).resolve().parents[1]
URL='https://github.com/YosysHQ/oss-cad-suite-build/releases/download/2026-10-28/oss-cad-suite-windows-x64-20261028.tgz'
SHA='eb97af9e5d0b195e570c6a7ee3d29c005bcc60e343d48cb713ef414e4a39e766'
def main():
    p=argparse.ArgumentParser();p.add_argument('--download',action='store_true');a=p.parse_args()
    if not a.download: print('No changes. Add --download to fetch the pinned 603,471,724-byte Windows tool archive.');return
    root=ROOT/'.tools';root.mkdir(exist_ok=True);archive=root/'oss-cad-suite-windows-x64-20261028.tgz'
    if not archive.exists():
        temp=archive.with_suffix('.part')
        with urllib.request.urlopen(URL,timeout=60) as src,temp.open('wb') as dst:
            while block:=src.read(1024*1024):dst.write(block)
        if temp.stat().st_size!=603471724 or hashlib.file_digest(temp.open('rb'),'sha256').hexdigest()!=SHA:raise SystemExit('Download size/hash mismatch; nothing extracted.')
        temp.rename(archive)
    if hashlib.file_digest(archive.open('rb'),'sha256').hexdigest()!=SHA:raise SystemExit('Archive SHA-256 mismatch; nothing extracted.')
    target=root/'oss-cad-suite'
    if target.exists():raise SystemExit('Tool folder already exists; it was not overwritten. Use the existing folder or inspect it first.')
    with tarfile.open(archive) as tar:
        for member in tar.getmembers():
            if not (root/member.name).resolve().is_relative_to(root.resolve()):raise SystemExit('Unsafe archive path')
        tar.extractall(root,filter='data')
    print(json.dumps({'tools':str(target),'sha256':SHA,'global_path_modified':False}))
if __name__=='__main__':main()
